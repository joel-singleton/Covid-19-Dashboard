from flask import Flask
from flask import render_template 
from flask import request
from flask import redirect
import webbrowser
from covid_news_handling import *
from time_conversions import *

#Opens the web page
webbrowser.open(config['link'])

app = Flask(__name__)

#The below functions are called to get the inital data required for the dashboard
all_covid_data()
news_API_request()

#A global list containing a series of dictionaries for the update messages
update_messages = []

def schedule_event():
    """When called the update time is fetched from the link and the current time is also fetched. These times are used to 
    calculate the update_time_seconds which is the time in seconds from the current time for when an update will be scheduled.
    Depending on which boxes were selected from the form, various functions are called to update either the news articles or covid
    data. And for each the schedule_event_message function is also called.
    """
    try:
        update_time = request.args.get('update')
        update_time_seconds = hhmm_to_seconds(update_time)
        update_time_seconds = update_time_seconds - current_time_seconds()
    except:
        logging.error('Unable to get update time for sheduled event')
        return None
    if request.args.get('covid-data') and request.args.get('news') and request.args.get('repeat'):
        update_news(news_API_request, update_time_seconds, 3)
        schedule_covid_updates(all_covid_data, update_time_seconds, 3)
        schedule_event_message(update_time, 'Update news articles', True)
        schedule_event_message(update_time, 'Update Covid data', True)
    elif request.args.get('covid-data') and request.args.get('news') and not request.args.get('repeat'):
        update_news(news_API_request, update_time_seconds, 1)
        schedule_covid_updates(all_covid_data, update_time_seconds, 1)
        schedule_event_message(update_time, 'Update news articles', False)
        schedule_event_message(update_time, 'Update Covid data', False)
    else:
        if request.args.get('covid-data') and request.args.get('repeat'):
            schedule_covid_updates(all_covid_data, update_time_seconds, 3)
            schedule_event_message(update_time, 'Update Covid data', True)
        elif request.args.get('covid-data') and not request.args.get('repeat'):
            schedule_covid_updates(all_covid_data, update_time_seconds, 1)
            schedule_event_message(update_time, 'Update Covid data', False)
        elif request.args.get('news') and request.args.get('repeat'):
            update_news(news_API_request, update_time_seconds, 3)
            schedule_event_message(update_time, 'Update news articles', True)
        elif request.args.get('news') and not request.args.get('repeat'):
            update_news(news_API_request, update_time_seconds, 1)
            schedule_event_message(update_time, 'Update news articles', False)

def schedule_event_message(time, update, repeat):
    """Creates a dictionary to display update messages on the dashboard.

    :param time: [string]: The time of the scheduled update
    :param update: [string]: The title of the update to specify whether it is covid data or news articles being updated
    :param repeat: [boolean]: Has a True value if it is a repeat update
    :return: update_messages [dictionary]: Contains all update messages for the schedule requests
    """
    try:
        if repeat == True:
            content = 'A repeat update has been scheduled for ' + time
        else:
            content = 'An update has been scheduled for ' + time
        update_messages.append({
            'title': update,
            'content': content,
            'update_label': request.args.get('two'),
        })
        logging.info("{0} - {1}".format(update, content))
        return update_messages
    except:
        logging.error('Error adding update message')
        return None

def remove_scehdule_event_message(remove_update):
    """Compares the update label fetched from the link for the article to be removed and compares it against 
    all update labels from the dictionary updates_messages and the deletes the one that matches from the dictionary

    :param remove_update: [string]: The update label for the update message being removed
    """
    try:
        for i in range(0, len(update_messages)):
            if remove_update in update_messages[i]['update_label']:
                del update_messages[i]
                break 
        logging.info("Update message removed with update label: {0}".format(remove_update))
    except:
        pass
        logging.error('Error removing shedule event message')

def fetch_covid_data():
    """Opens the file containing the covid data and reads it, then stores it in a list which is returned

    :return: [list]: contains all of the data to be displayed on the covid dashboard
    """
    try:
        covid_data = []
        with open(config['covid_data_file']) as file:
            for line in file:
                covid_data.append(line.strip())
        logging.info('Covid data fetched from text file')
        return covid_data
    except:
        pass
        logging.error('Error fetching data from covid data file')

def fecth_news_data():
    """Opens the file containing the news data and reads it, then returns it as a dictionary

    :return: [dictionary]: A dcitionary containing all of the news articles to be displayed on the dashboard
    """
    try:
        with open(config['news_file']) as json_file:
            news_data = json.load(json_file)
        logging.info('News data fetched from json file')
        return news_data
    except:
        pass
        logging.error('Error fetching data from news data file')

def fetch_update_messages():
    """Allows the global varibale containing the update messages to be returned when the dashboard refreshes

    :return: update_messages [list]: Contains all update messages for the schedule requests  
    """
    return update_messages

@app.route('/')
def home():
    return redirect('/index')
@app.route('/index')
def main():
    """The main function which is run when the program is first launched. A series of conditonal statments are used for interactions
    with the dashboard, such as when the user wants to remove a news article or schedule an update, the appropriate functions are then
    called to update the dashboard accordingly. 

    :return: The template for the covid dashboard (index.html). This is returned every 60 seconds, unless refreshed by the user.
    """
    logging.info('Page refreshed')
    print('logging failed')
    s.run(blocking=False)
    remove_news = request.args.get('notif')
    if remove_news:
        logging.info("News article removed with title: {0}".format(remove_news))
        removed_news_articles.append(remove_news)
        logging.info("Removed news article added to list containing all removed news articles")
        news_API_request() 
        fecth_news_data()
    remove_update = request.args.get('update_item')
    if remove_update:
        remove_scehdule_event_message(remove_update)
        fetch_update_messages()
    submit = request.args.get('two')
    if submit:
        schedule_event()
    return render_template('index.html', 
        title = config['user_interface_title'],
        location = config['user_interface_location'],
        nation_location = config['user_interface_nation_location'],
        local_7day_infections = fetch_covid_data()[0], 
        national_7day_infections = fetch_covid_data()[1],
        hospital_cases = fetch_covid_data()[2],
        deaths_total = fetch_covid_data()[3], 
        news_articles = fecth_news_data(),
        updates = fetch_update_messages(), 
        image = config['user_interface_image'])

if __name__ == '__main__':
    app.run()
