INTRODUCTION
This is an automated Covid-19 dashboard which runs continously and responds to events initiated by the user. The user can schedule 
updates for news articles and covid data which are updated via api requests. The user can also view the latest news articles
relevant to Covid-19

PREREQUISITES 
Python version 3.8.0

INSTALLATION
1. Get a free API key at https://newsapi.org/
2. Enter your API in config.txt
3. Install the following packages:
$ pip install uk-covid19
$ pip install schedule
$ pip install requests
$ pip install Flask
$ pip install logging

GETTING STARTED
The covid dashboard can be launched by running the module 'covid_user_interface' and the web page should automatically open.
If not a link can be found in the console. 

USAGE
From the covid dashboard you can schedule updates by filling in the form. You can see the latest news articles view the full
article by clicking on the link, also remove unwanted news articles. To change the locations for either the local or national data, 
you can edit this from the config file along with other things. Every time the program is run a new log file is created within the 'logs' 
folder and the time and date of that session is saved in the name of each log. 

TESTING
There are 2 modules for testing:
test_covid_data_handler
test_news_data_handling

CONTACT
Joel Singleton - js1423@exeter.ac.uk
github link - 

LICENSE
See license.txt for more information

DEVELOPER DOCUMENTATION
The purpose of each function is descibed by a docstring. The api requests can be easily extended to fetch more data and the dashboard 
can be easily customised from the index.html within templates. The image in static can also be customized. 






