from covid_data_handler import *
import requests

def news_API_request(covid_terms = config['news_query_terms']):
    """Sends an api request to fetch relevant news articles conataining the query terms. The api request returns a dictionary
    of news articles which is then sent to the function get_unique_news_articles, which is then written to a json file.

    :param covid_terms: [list]: A list contiaing the specefic key query terms for the api request, defaults to config['news_query_terms']
    :return: unique_news_articles [dictionary]: Contains all unqique news articles, once compared against previously removed ones.
    """
    try:
        url = config['news_url']
        parameters = {
        'q': covid_terms, 
        'apiKey': config['apiKey']
        }
        response = requests.get(url, params=parameters).json()
        news_articles = (response['articles'])
        unique_news_articles = get_unique_news_articles(news_articles)
        with open(config['news_file'], 'w') as outfile:
            json.dump(unique_news_articles, outfile)
        logging.info('News api request called and news data file updated')
        return unique_news_articles
    except:
        print('News api request failed')
        #logging.error('News api request failed')
        return None

def update_news(news_name, news_interval, repeat = 1):
    """Handles schedular reuqests for updating news articles

    :param news_name: The function called when the schedular reuqest is executed
    :param news_interval: The time in seconds for when the request will be executed 
    :param repeat: determines how many times the schedular request is executed, defaults to 1
    """
    try:
        s.enter(news_interval, repeat, news_name, "")
        print('updating news...')
        logging.info('Scheduled update request for news data successful')
    except:
        pass
        #logging.error('Unable to execute schedule request for news data')

def get_unique_news_articles(news_articles):
    """Compares the titles of all of the news articles from the api request against all of the tittles of
    news articles which have been removed from the dashboard and stored in the list removed_news_articles. The unique 
    articles news are then added to a new dictionary

    :param news_articles: [dictionary] Contains all news articles fetched from the news api request.
    :return: unique_news_articles [dictionary]: Contains all unqique news articles, once compared against previously removed ones.
    """
    try:
        unique_news_articles = []
        for i in range(0, len(news_articles)):
            if news_articles[i]['title'] not in removed_news_articles:
             unique_news_articles.append(news_articles[i])
        print(unique_news_articles)
        return unique_news_articles
    except:
        print('Unable to compare news artiles')
        #logging.error('Unable to get unique news articles')
        return news_articles

#global list containing the titles of all removed news artilces 
removed_news_articles = []
s.run()