import datetime
import logging
from uk_covid19 import Cov19API
import sched
import time
import json 

logging.basicConfig(filename='logs/log{}.log'.format(datetime.datetime.strftime(datetime.datetime.now(), '_%Y-%m-%d__%H-%M-%S')), level=logging.INFO)

s = sched.scheduler(time.time, time.sleep)

#Opens config file to allow access throughout the code
try:
    with open('config.txt', 'r') as f:
        config = json.load(f)
except:
    print('error opening file')

def parse_csv_data(f):
    """Reads data from a csv file and adds it to a list"""
    data = []
    try:
        file = open(f, 'r')
        for line in file:
            data.append(line.strip().split(','))
        file.close()
    except:
        print('Error opening file')
    return data

def process_covid_csv_data(data):
    """Processes the values from the list data in order to return specefic data"""
    try:
        current_hospital_cases = int(data[1][5])
    except:
        current_hospital_cases = 0
    last7days_cases = 0
    total_deaths = 0
    try:
        for i in range(3,10):
            last7days_cases += int(data[i][6])
    except:
        pass
    try:
        for i in range(1, len(data)):
            if data[i][4] != '':
                total_deaths = int(data[i][4])
                break
    except:
        pass
    return last7days_cases, current_hospital_cases, total_deaths

def covid_API_request(location = config['area_name_local'], location_type = config['area_type_local']):
    """Sends an api request using the cov19API module to recieve up to date covid data and stores it as a dictionary

    :param location: [string]: The location for the api request, Defaults to config['area_name_local'].
    :param location_type: [string]: The location type for the api request, Defaults to config['area_type_local'].
    :return: data [dictioary]: Contains all fields of data defined in the structure below for the specefic location
    """
    try:
        filters = [
            f"areaType={location_type}",
            f"areaName={location}",
        ]

        structure = {
            "areaCode": "areaCode",
            "areaName": "areaName",
            "areaType" : "areaType",
            "date": "date",
            "cumDailyNsoDeathsByDeathDate": "cumDailyNsoDeathsByDeathDate",
            "hospitalCases" : "hospitalCases",
            "newCasesByPublishDate": "newCasesByPublishDate",
        }

        api = Cov19API(filters, structure)
        data = api.get_json()
        return data
    except:
        #logging.error('Covid API request failed')
        return None

def process_covid_json_data(data):
    """Processes the dictionary containing data from the api request in order to return specefic figures

    :param data: data [dictioary]: Contains all fields of data defined in the structure below.
    :return: last7day_infection [integer]: The total of the infections from the last 7 days.
             hospital_cases [integer]: The latest number of hosptial cases from the most recent day.
             total_deaths [integer] : The cumulative total of deaths from all dates.
    """
    last7day_infections = 0
    hospital_cases = 0
    total_deaths = 0
    try:
        for i in range(0, 7):
            last7day_infections += data['data'][i]['newCasesByPublishDate']
    except:
        pass
    try:
        for i in range(0, len(data['data'])):
            if data['data'][i]['hospitalCases'] != None:
                hospital_cases = data['data'][i]['hospitalCases']
                break
    except:
        pass
    try:
        for i in range(0, len(data['data'])):
            if data['data'][i]['cumDailyNsoDeathsByDeathDate'] != None:
                total_deaths = data['data'][i]['cumDailyNsoDeathsByDeathDate']
                break
    except:
        pass
    return last7day_infections, hospital_cases, total_deaths

def all_covid_data():
    """Calls the covid_API_reuqest and process_covid_json_data functions multiple times with different
    arguments to recieve national and local data for the covid dashboard. This data is then put into a list which is then
    written to a json file"""
    local_7day_infections = process_covid_json_data(covid_API_request(config['area_name_local'], config['area_type_local']))[0]
    national_7day_infections, hospital_cases, deaths_total = process_covid_json_data(covid_API_request(config['area_name_national'],config['area_type_national']))
    data = [local_7day_infections, national_7day_infections, hospital_cases, deaths_total]
    print(data)
    try:
        with open(config['covid_data_file'], 'w') as file:
            for i in data:
                file.write(str(i))
                file.write('\n')
        logging.info('Covid data api request called and covid data file updated')
    except:
        pass
        #logging.error('Unable to write to covid data file')

def schedule_covid_updates(update_name, update_interval, repeat = 1):
    """Handles schedular reuqests for updating the covid data

    :param update_name: The function called when the schedular reuqest is executed
    :param update_interval: The time in seconds for when the request will be executed 
    :param repeat: Determines how many times the schedular request is executed, defaults to 1
    """
    try:
        s.enter(update_interval, repeat, update_name, "")
        print('updating covid data...')
        logging.info('Schedule update request for covid data successful')
    except:
        pass
        #logging.error('Unable to execute schedule request for covid data')
        
s.run()