from covid_news_handling import *

def test_news_API_request():
    assert news_API_request()
    assert news_API_request(['Covid', 'COVID-19', 'coronavirus']) == news_API_request()
    print('News API test successful')

def test_update_news():
    update_news(news_API_request, 10)
    print('Update news test successful')

test_news_API_request()
test_update_news()

s.run()